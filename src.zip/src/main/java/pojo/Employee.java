package pojo;

public class Employee {
}
