package mapper;


public interface EmployeeMapper {
}
